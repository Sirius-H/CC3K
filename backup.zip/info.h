#ifndef __INFO_H__
#define __INFO_H__
#include "coordinate.h"
struct Info {
    Coordinate cdn;
    char item;
    int effectCode;
};

#endif
